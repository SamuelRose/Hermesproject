import React from "react";
// import logo from "./logo.svg";
import "./App.css";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      messages: []
    };
  }

  uploadHandler(event) {
    
    console.log(event.target.files[0]);
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0
    });
  }

  onClickHandler(event) {
    document.getElementById("sendbutton").hidden = false;
    document.getElementById("text").hidden = false;
    const data = new FormData();
    data.append("file", this.state.selectedFile);
    console.log(data);
  }

  updateInputValue(event) {
    this.setState({
      currentValue: event.target.value
    });
  }

  onSubmitInput(event) {
    event.preventDefault();
    console.log(this.state.currentValue);
    let messages = this.state.messages;
    messages.push(this.state.currentValue);

    this.setState({
      currentValue: "",
      messages: messages
    });

    //api call to your backend
    // return is yoo!

    setTimeout(() => {
      let retVal = "yoo!";
      messages.push(retVal);
      this.setState({
        messages: messages
      });
    }, 1000);
  }

  render() {
    return (
      <div className="App">
        
        <h1 style={{color: "white",
                   fontSize : '40',
                   }}>Hermes</h1>
        
        <h2 style = {{color: "white",
                      fontSize : '10'}}>Injury Response and Relay Service</h2>
        <p></p>
        <input type="file" onChange={e => this.uploadHandler(e)}></input>
        <br />
        <button type="button" id= "uploadbutton" onClick={e => this.onClickHandler(e)}>
          Upload
        </button>
        <br />
        <input id = "text" hidden = "hidden"
          value={this.state.currentValue}
          onChange={e => this.updateInputValue(e)}
        />
        <button type="button" id = "sendbutton" name ="Send" hidden = "hidden" onClick={e => this.onSubmitInput(e)} style = {{borderBlockColor : "green"}}>
          Send
        </button>
        <div>
          {this.state.messages.map(item => (
            <p>{item}</p>
          ))}
        </div>
      </div>
    );
  }
}

export default App;
