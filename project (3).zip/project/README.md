"Hermesproject-a project for helping people during natural disasters" 
